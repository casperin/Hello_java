package dk.itu.gp.florida;

public class Dolphin extends Mammal {

	public Dolphin(String name) {
		super(name);
	}

	@Override
	public String speak() {
		return "Squeeek";
	}

}
