package dk.itu.gp.florida;

public class Manatee extends Mammal {
	

	public Manatee(String name) {
		super(name);
	}

	@Override
	public String speak() {
		return "Blubb";
	}

}
