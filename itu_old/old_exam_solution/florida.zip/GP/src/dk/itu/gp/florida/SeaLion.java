package dk.itu.gp.florida;

public class SeaLion extends Mammal {

	public SeaLion(String name) {
		super(name);
	}

	@Override
	public String speak() {
		return "Gruff";
	}

}
